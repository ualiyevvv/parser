const { DataTypes, Model  } = require('sequelize');
const sequelize = require('../db');

const Category = sequelize.define('category', {
    subsection: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    link: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    subcategories: {
        type: DataTypes.JSON,
        allowNull: false,
    },
    length: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
});

module.exports = Category;

