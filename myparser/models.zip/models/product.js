const { DataTypes } = require('sequelize');
const sequelize = require('../db');

// Модель продукта
const Product = sequelize.define('Product', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
    },
    images: {
        type: DataTypes.JSON,
        allowNull: true,
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    price: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    oldPrice: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    rating: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    reviewsCount: {
        type: DataTypes.STRING,
        allowNull: true,
    },
}, {
    timestamps: true, // Добавление полей createdAt и updatedAt
    createdAt: 'created_at', // Название поля для времени создания
    updatedAt: 'updated_at', // Название поля для времени обновления
});

module.exports = Product;
