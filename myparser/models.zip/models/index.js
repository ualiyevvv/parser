const sequelize = require("../db");
const Category = require('./category')
const Product = require('./product');
const Tag = require('./tag');
const ProductTag = require('./product_tag');


// Определение связей между моделями
Product.belongsToMany(Tag, { through: ProductTag });
Tag.belongsToMany(Product, { through: ProductTag });

// // Синхронизируем модели с базой данных
// (async () => {
//     try {
//         await sequelize.sync();
//         console.log('All models were synchronized successfully.');
//     } catch (error) {
//         console.error('Unable to synchronize the database:', error);
//     }
// })();

module.exports = {
    Product,
    Tag,
    ProductTag,
    Category
};
