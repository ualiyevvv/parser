const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const ProductTag = sequelize.define('ProductTag', {
    productId: {
        type: DataTypes.INTEGER,
        references: {
            model: 'Product',
            key: 'id',
        },
        onDelete: 'CASCADE',
        allowNull: false,
    },
    tagId: {
        type: DataTypes.INTEGER,
        references: {
            model: 'Tag',
            key: 'id',
        },
        onDelete: 'CASCADE',
        allowNull: false,
    },
});

module.exports = ProductTag;
